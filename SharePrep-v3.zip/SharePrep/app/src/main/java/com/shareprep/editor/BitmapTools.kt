package com.shareprep.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

object BitmapLoader {
    private const val MAX_SIDE = 4096

    /** Decodes (with EXIF rotation applied) and caps the long side at 4096px. */
    suspend fun load(context: Context, uri: Uri): Bitmap = withContext(Dispatchers.IO) {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > MAX_SIDE) {
                val f = MAX_SIDE.toFloat() / m
                decoder.setTargetSize(
                    max(1, (info.size.width * f).roundToInt()),
                    max(1, (info.size.height * f).roundToInt())
                )
            }
        }
    }
}

object BitmapProcessor {
    /** Applies crop then covers and returns a brand-new bitmap. The source is not modified. */
    fun process(src: Bitmap, crop: NRect, covers: List<Cover>): Bitmap {
        val w = src.width
        val h = src.height
        val left = (crop.left * w).roundToInt().coerceIn(0, w - 1)
        val top = (crop.top * h).roundToInt().coerceIn(0, h - 1)
        val right = (crop.right * w).roundToInt().coerceIn(left + 1, w)
        val bottom = (crop.bottom * h).roundToInt().coerceIn(top + 1, h)

        val out = Bitmap.createBitmap(right - left, bottom - top, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val full = RectF(-left.toFloat(), -top.toFloat(), (w - left).toFloat(), (h - top).toFloat())
        canvas.drawBitmap(src, null, full, Paint(Paint.FILTER_BITMAP_FLAG))
        if (covers.isNotEmpty()) {
            CoverRenderer.drawCovers(canvas, covers, CoverRenderer.makeBlurred(src), full)
        }
        return out
    }
}
