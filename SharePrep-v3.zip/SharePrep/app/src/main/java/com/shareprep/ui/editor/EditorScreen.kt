@file:OptIn(ExperimentalMaterial3Api::class)

package com.shareprep.ui.editor

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shareprep.data.Repository
import com.shareprep.editor.Cover
import com.shareprep.editor.CoverRenderer
import com.shareprep.editor.CoverType
import com.shareprep.editor.EditMode
import com.shareprep.editor.Handle
import com.shareprep.editor.NRect
import com.shareprep.editor.applyDrag
import com.shareprep.editor.computeFullDst
import com.shareprep.editor.hitHandle
import com.shareprep.editor.toScreen
import com.shareprep.ui.BackButton
import com.shareprep.ui.SelectionViewModel
import com.shareprep.ui.appViewModel

private val EMOJIS = listOf(
    "\uD83D\uDE48", "\uD83D\uDE49", "\uD83D\uDE4A", "\uD83D\uDE00", "\uD83D\uDE0E", "\uD83E\uDD10",
    "\uD83D\uDE36", "\uD83D\uDC31", "\u2B50", "\u2764\uFE0F", "\uD83D\uDD12", "\uD83D\uDEAB",
    "\uD83C\uDF38", "\uD83D\uDD25"
)

private val SWATCHES = listOf(
    Color.Black, Color.White, Color(0xFFE53935), Color(0xFF1E88E5),
    Color(0xFF43A047), Color(0xFFFDD835), Color(0xFFD81B60)
)

@Composable
fun EditorScreen(
    selection: SelectionViewModel,
    repo: Repository,
    onApproved: (Long) -> Unit,
    onSkip: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    // Captured once so the screen keeps its image while navigating on after approval.
    val uri = remember { selection.current }
    if (uri == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val vm = appViewModel(key = uri.toString()) {
        EditorViewModel(context.applicationContext as Application, repo)
    }
    LaunchedEffect(uri) { vm.load(uri) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit image") },
                navigationIcon = { BackButton(onBack) },
                actions = { TextButton(onClick = onSkip) { Text("Skip") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Box(
                Modifier.weight(1f).fillMaxWidth().padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                val bmp = vm.bitmap
                val bl = vm.blurred
                val err = vm.error
                when {
                    err != null -> Text(err)
                    bmp == null || bl == null -> CircularProgressIndicator()
                    else -> EditCanvas(
                        bitmap = bmp,
                        blurred = bl,
                        mode = vm.mode,
                        crop = vm.crop,
                        covers = vm.covers.toList(),
                        selectedId = vm.selectedId,
                        onCropChange = vm::setCrop,
                        onCoverChange = vm::updateCoverRect,
                        onSelect = vm::select,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
            ToolPanel(vm)
            Button(
                onClick = { vm.approve(onApproved) },
                enabled = vm.bitmap != null && !vm.saving,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Text(
                    when {
                        vm.saving -> "Saving..."
                        vm.hasEdits -> "Approve with edits"
                        else -> "Quick approve"
                    }
                )
            }
        }
    }
}

@Composable
private fun ToolPanel(vm: EditorViewModel) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = vm.mode == EditMode.CROP,
                onClick = { vm.switchMode(EditMode.CROP) },
                label = { Text("Crop") }
            )
            FilterChip(
                selected = vm.mode == EditMode.COVER,
                onClick = { vm.switchMode(EditMode.COVER) },
                label = { Text("Cover") }
            )
        }

        if (vm.mode == EditMode.CROP) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Drag corners or edges to crop freely.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { vm.resetCrop() }, enabled = vm.crop != NRect.FULL) { Text("Reset") }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.addCover(CoverType.SOLID) }, modifier = Modifier.weight(1f)) { Text("+ Block") }
                OutlinedButton(onClick = { vm.addCover(CoverType.BLUR) }, modifier = Modifier.weight(1f)) { Text("+ Blur") }
                OutlinedButton(onClick = { vm.addCover(CoverType.EMOJI) }, modifier = Modifier.weight(1f)) { Text("+ Emoji") }
            }
            val sel = vm.selected
            if (sel == null) {
                Text(
                    "Add a cover, then drag it to move or drag its corners to resize.",
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when (sel.type) {
                        CoverType.SOLID -> LazyRow(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(SWATCHES) { c ->
                                val on = sel.color == c.toArgb()
                                Box(
                                    Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(c)
                                        .border(
                                            if (on) 3.dp else 1.dp,
                                            if (on) MaterialTheme.colorScheme.primary else Color.Gray,
                                            CircleShape
                                        )
                                        .clickable { vm.setColor(c.toArgb()) }
                                )
                            }
                        }
                        CoverType.EMOJI -> LazyRow(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(EMOJIS) { e ->
                                Text(
                                    e,
                                    fontSize = 28.sp,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (sel.emoji == e) MaterialTheme.colorScheme.surfaceVariant
                                            else Color.Transparent
                                        )
                                        .clickable { vm.setEmoji(e) }
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        CoverType.BLUR -> Text(
                            "Blur (drag to move, corners to resize)",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    IconButton(onClick = { vm.deleteSelected() }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete cover")
                    }
                }
            }
        }
    }
}

@Composable
private fun EditCanvas(
    bitmap: Bitmap,
    blurred: Bitmap,
    mode: EditMode,
    crop: NRect,
    covers: List<Cover>,
    selectedId: Long?,
    onCropChange: (NRect) -> Unit,
    onCoverChange: (Long, NRect) -> Unit,
    onSelect: (Long?) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val tol = with(density) { 28.dp.toPx() }
    val handleR = with(density) { 8.dp.toPx() }
    val strokeW = with(density) { 2.dp.toPx() }

    val curMode by rememberUpdatedState(mode)
    val curCrop by rememberUpdatedState(crop)
    val curCovers by rememberUpdatedState(covers)
    val curSel by rememberUpdatedState(selectedId)
    val cropCb by rememberUpdatedState(onCropChange)
    val coverCb by rememberUpdatedState(onCoverChange)
    val selectCb by rememberUpdatedState(onSelect)
    val bmpPaint = remember { Paint(Paint.FILTER_BITMAP_FLAG) }

    fun fullFor(w: Float, h: Float, m: EditMode, c: NRect) =
        computeFullDst(w, h, bitmap.width, bitmap.height, if (m == EditMode.CROP) NRect.FULL else c)

    Canvas(
        modifier = modifier
            .pointerInput(bitmap) {
                detectTapGestures { pos ->
                    if (curMode == EditMode.COVER) {
                        val full = fullFor(size.width.toFloat(), size.height.toFloat(), curMode, curCrop)
                        val hit = curCovers.lastOrNull { it.rect.toScreen(full).contains(pos.x, pos.y) }
                        selectCb(hit?.id)
                    }
                }
            }
            .pointerInput(bitmap) {
                var handle = Handle.NONE
                var targetId = -1L
                var work = NRect.FULL
                detectDragGestures(
                    onDragStart = { pos ->
                        val full = fullFor(size.width.toFloat(), size.height.toFloat(), curMode, curCrop)
                        handle = Handle.NONE
                        if (curMode == EditMode.CROP) {
                            handle = hitHandle(curCrop.toScreen(full), pos, tol, true)
                            work = curCrop
                        } else {
                            val sel = curCovers.firstOrNull { it.id == curSel }
                            var chosen: Cover? = null
                            if (sel != null) {
                                val h = hitHandle(sel.rect.toScreen(full), pos, tol, false)
                                if (h != Handle.NONE) {
                                    chosen = sel
                                    handle = h
                                }
                            }
                            if (chosen == null) {
                                val hit = curCovers.lastOrNull { it.rect.toScreen(full).contains(pos.x, pos.y) }
                                if (hit != null) {
                                    chosen = hit
                                    val h = hitHandle(hit.rect.toScreen(full), pos, tol, false)
                                    handle = if (h == Handle.NONE) Handle.MOVE else h
                                    selectCb(hit.id)
                                }
                            }
                            if (chosen != null) {
                                targetId = chosen.id
                                work = chosen.rect
                            }
                        }
                    },
                    onDrag = { change, drag ->
                        if (handle != Handle.NONE) {
                            change.consume()
                            val full = fullFor(size.width.toFloat(), size.height.toFloat(), curMode, curCrop)
                            val dx = drag.x / full.width()
                            val dy = drag.y / full.height()
                            if (curMode == EditMode.CROP) {
                                work = applyDrag(work, handle, dx, dy, NRect.FULL)
                                cropCb(work)
                            } else {
                                work = applyDrag(work, handle, dx, dy, curCrop)
                                coverCb(targetId, work)
                            }
                        }
                    },
                    onDragEnd = { handle = Handle.NONE },
                    onDragCancel = { handle = Handle.NONE }
                )
            }
    ) {
        val full = fullFor(size.width, size.height, mode, crop)
        val view = if (mode == EditMode.CROP) NRect.FULL else crop
        val visible = view.toScreen(full)

        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            nc.save()
            nc.clipRect(visible)
            nc.drawBitmap(bitmap, null, full, bmpPaint)
            CoverRenderer.drawCovers(nc, covers, blurred, full)
            nc.restore()
        }

        if (mode == EditMode.CROP) {
            val cr = crop.toScreen(full)
            val dim = Color(0x99000000)
            drawRect(dim, Offset(visible.left, visible.top), Size(visible.width(), cr.top - visible.top))
            drawRect(dim, Offset(visible.left, cr.bottom), Size(visible.width(), visible.bottom - cr.bottom))
            drawRect(dim, Offset(visible.left, cr.top), Size(cr.left - visible.left, cr.height()))
            drawRect(dim, Offset(cr.right, cr.top), Size(visible.right - cr.right, cr.height()))
            drawRect(
                Color.White, Offset(cr.left, cr.top), Size(cr.width(), cr.height()),
                style = Stroke(strokeW)
            )
            val mx = (cr.left + cr.right) / 2f
            val my = (cr.top + cr.bottom) / 2f
            for (p in listOf(
                Offset(cr.left, cr.top), Offset(cr.right, cr.top),
                Offset(cr.left, cr.bottom), Offset(cr.right, cr.bottom),
                Offset(mx, cr.top), Offset(mx, cr.bottom),
                Offset(cr.left, my), Offset(cr.right, my)
            )) drawHandle(p, handleR)
        } else {
            for (cv in covers) {
                val r = cv.rect.toScreen(full)
                val isSel = cv.id == selectedId
                drawRect(
                    if (isSel) Color(0xFF9ECAFF) else Color(0x88FFFFFF),
                    Offset(r.left, r.top), Size(r.width(), r.height()),
                    style = Stroke(if (isSel) strokeW else strokeW / 2f)
                )
                if (isSel) {
                    for (p in listOf(
                        Offset(r.left, r.top), Offset(r.right, r.top),
                        Offset(r.left, r.bottom), Offset(r.right, r.bottom)
                    )) drawHandle(p, handleR)
                }
            }
        }
    }
}

private fun DrawScope.drawHandle(center: Offset, radius: Float) {
    drawCircle(Color.White, radius, center)
    drawCircle(Color(0xFF2962FF), radius * 0.6f, center)
}
