@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.shareprep.ui.tags

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.shareprep.data.Repository
import com.shareprep.ui.BackButton
import com.shareprep.ui.appViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class TagAssignViewModel(private val repo: Repository, private val imageId: Long) : ViewModel() {
    val tags = repo.tagsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val selected = mutableStateListOf<Long>()
    var newName by mutableStateOf("")
    var path by mutableStateOf<String?>(null)

    init {
        viewModelScope.launch {
            path = repo.image(imageId)?.filePath
            repo.tagIdsFor(imageId).forEach { if (it !in selected) selected.add(it) }
        }
    }

    fun toggle(id: Long) {
        if (id in selected) selected.remove(id) else selected.add(id)
    }

    fun addTag() {
        val name = newName
        viewModelScope.launch {
            repo.createTag(name)?.let { if (it !in selected) selected.add(it) }
            newName = ""
        }
    }

    fun save(onDone: () -> Unit) {
        viewModelScope.launch {
            repo.setTags(imageId, selected.toSet())
            onDone()
        }
    }
}

@Composable
fun TagAssignScreen(
    repo: Repository,
    imageId: Long,
    batch: Boolean,
    remaining: Int,
    onDone: () -> Unit,
    onBack: () -> Unit
) {
    val vm = appViewModel(key = "tags-$imageId") { TagAssignViewModel(repo, imageId) }
    val tags by vm.tags.collectAsStateWithLifecycle()

    // In the batch flow the image is already saved, so Back just saves the tags and moves on.
    BackHandler(enabled = batch) { vm.save(onDone) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tags") },
                navigationIcon = { if (!batch) BackButton(onBack) }
            )
        },
        bottomBar = {
            Button(
                onClick = { vm.save(onDone) },
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Text(if (batch && remaining > 0) "Save & next ($remaining left)" else "Save")
            }
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            vm.path?.let {
                AsyncImage(
                    model = File(it),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                )
            }
            Text("Choose tags", style = MaterialTheme.typography.titleMedium)
            if (tags.isEmpty()) {
                Text("No tags yet. Create one below.", style = MaterialTheme.typography.bodyMedium)
            }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tags.forEach { t ->
                    FilterChip(
                        selected = t.id in vm.selected,
                        onClick = { vm.toggle(t.id) },
                        label = { Text(t.name) }
                    )
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = vm.newName,
                    onValueChange = { vm.newName = it },
                    label = { Text("New tag") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { vm.addTag() })
                )
                Button(onClick = { vm.addTag() }, enabled = vm.newName.isNotBlank()) { Text("Add") }
            }
        }
    }
}
