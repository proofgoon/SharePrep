@file:OptIn(ExperimentalMaterial3Api::class)

package com.shareprep.ui.gallery

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.shareprep.data.Repository
import com.shareprep.ui.BackButton
import com.shareprep.ui.appViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class TrashViewModel(private val repo: Repository) : ViewModel() {
    val rows = repo.trashed.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun restore(id: Long) { viewModelScope.launch { repo.restore(id) } }
    fun deleteForever(id: Long) { viewModelScope.launch { repo.deleteForever(id) } }
    fun emptyTrash() {
        viewModelScope.launch { rows.value.forEach { repo.deleteForever(it.image.id) } }
    }
}

@Composable
fun TrashScreen(repo: Repository, onBack: () -> Unit) {
    val vm = appViewModel { TrashViewModel(repo) }
    val rows by vm.rows.collectAsStateWithLifecycle()
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmId by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trash") },
                navigationIcon = { BackButton(onBack) },
                actions = {
                    TextButton(onClick = { confirmEmpty = true }, enabled = rows.isNotEmpty()) { Text("Empty") }
                }
            )
        }
    ) { pad ->
        if (rows.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Trash is empty.", style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp)) {
                items(rows, key = { it.image.id }) { item ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = File(item.image.filePath),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(72.dp).clip(RoundedCornerShape(8.dp))
                        )
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(
                                if (item.tags.isEmpty()) "No tags" else item.tags.joinToString(", ") { it.name },
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        TextButton(onClick = { vm.restore(item.image.id) }) { Text("Restore") }
                        IconButton(onClick = { confirmId = item.image.id }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete forever")
                        }
                    }
                }
            }
        }
    }

    confirmId?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmId = null },
            title = { Text("Delete permanently?") },
            text = { Text("This removes the processed image from the app. Your original is not affected.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteForever(id); confirmId = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmId = null }) { Text("Cancel") } }
        )
    }
    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("Empty Trash?") },
            text = { Text("All trashed images will be deleted permanently.") },
            confirmButton = {
                TextButton(onClick = { vm.emptyTrash(); confirmEmpty = false }) { Text("Empty") }
            },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text("Cancel") } }
        )
    }
}
