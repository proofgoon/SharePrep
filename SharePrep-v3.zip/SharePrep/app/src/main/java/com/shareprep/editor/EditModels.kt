package com.shareprep.editor

import android.graphics.RectF
import androidx.compose.ui.geometry.Offset
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Rectangle in normalized coordinates (0..1) relative to the ORIGINAL decoded image. */
data class NRect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top

    companion object {
        val FULL = NRect(0f, 0f, 1f, 1f)
    }
}

enum class CoverType { SOLID, BLUR, EMOJI }
enum class EditMode { CROP, COVER }
enum class Handle { NONE, MOVE, TL, TR, BL, BR, L, R, T, B }

data class Cover(
    val id: Long,
    val type: CoverType,
    val rect: NRect,
    val emoji: String = "\uD83D\uDE48",
    val color: Int = 0xFF000000.toInt()
)

const val MIN_SIZE = 0.03f

fun NRect.toScreen(full: RectF): RectF = RectF(
    full.left + left * full.width(),
    full.top + top * full.height(),
    full.left + right * full.width(),
    full.top + bottom * full.height()
)

/** Where the whole original image is drawn on screen so that [view] fits the canvas. */
fun computeFullDst(canvasW: Float, canvasH: Float, imgW: Int, imgH: Int, view: NRect): RectF {
    val vw = max(1f, view.width * imgW)
    val vh = max(1f, view.height * imgH)
    val s = min(canvasW / vw, canvasH / vh)
    val ox = (canvasW - vw * s) / 2f - view.left * imgW * s
    val oy = (canvasH - vh * s) / 2f - view.top * imgH * s
    return RectF(ox, oy, ox + imgW * s, oy + imgH * s)
}

fun hitHandle(r: RectF, p: Offset, tol: Float, edges: Boolean): Handle {
    val t = minOf(tol, r.width() / 3f, r.height() / 3f)
    fun nx(x: Float) = abs(p.x - x) <= t
    fun ny(y: Float) = abs(p.y - y) <= t
    if (nx(r.left) && ny(r.top)) return Handle.TL
    if (nx(r.right) && ny(r.top)) return Handle.TR
    if (nx(r.left) && ny(r.bottom)) return Handle.BL
    if (nx(r.right) && ny(r.bottom)) return Handle.BR
    if (edges) {
        val inX = p.x >= r.left - t && p.x <= r.right + t
        val inY = p.y >= r.top - t && p.y <= r.bottom + t
        if (nx(r.left) && inY) return Handle.L
        if (nx(r.right) && inY) return Handle.R
        if (ny(r.top) && inX) return Handle.T
        if (ny(r.bottom) && inX) return Handle.B
    }
    if (p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom) return Handle.MOVE
    return Handle.NONE
}

fun applyDrag(r: NRect, h: Handle, dx: Float, dy: Float, bounds: NRect): NRect {
    if (h == Handle.MOVE) {
        val w = r.width
        val hh = r.height
        val nl = (r.left + dx).coerceIn(bounds.left, bounds.right - w)
        val nt = (r.top + dy).coerceIn(bounds.top, bounds.bottom - hh)
        return NRect(nl, nt, nl + w, nt + hh)
    }
    var l = r.left
    var t = r.top
    var rr = r.right
    var b = r.bottom
    if (h == Handle.TL || h == Handle.BL || h == Handle.L) l = (l + dx).coerceIn(bounds.left, rr - MIN_SIZE)
    if (h == Handle.TR || h == Handle.BR || h == Handle.R) rr = (rr + dx).coerceIn(l + MIN_SIZE, bounds.right)
    if (h == Handle.TL || h == Handle.TR || h == Handle.T) t = (t + dy).coerceIn(bounds.top, b - MIN_SIZE)
    if (h == Handle.BL || h == Handle.BR || h == Handle.B) b = (b + dy).coerceIn(t + MIN_SIZE, bounds.bottom)
    return NRect(l, t, rr, b)
}

/** Shrinks/shifts [r] so it lies fully inside [b]. */
fun fitInto(r: NRect, b: NRect): NRect {
    val w = min(r.width, b.width)
    val h = min(r.height, b.height)
    val l = r.left.coerceIn(b.left, b.right - w)
    val t = r.top.coerceIn(b.top, b.bottom - h)
    return NRect(l, t, l + w, t + h)
}
