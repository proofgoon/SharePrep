package com.shareprep.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Draws cover regions. Used for both the live preview and the final export so they match. */
object CoverRenderer {

    /** Very strong blur: shrinks the image to ~28px on its long side (smooth when scaled back up). */
    fun makeBlurred(src: Bitmap): Bitmap {
        val longest = max(src.width, src.height)
        val scale = 28f / longest
        val tw = max(1, (src.width * scale).roundToInt())
        val th = max(1, (src.height * scale).roundToInt())
        var cur = src
        while (cur.width / 2 >= tw && cur.height / 2 >= th) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        val out = Bitmap.createScaledBitmap(cur, tw, th, true)
        if (cur !== src && cur !== out) cur.recycle()
        return out
    }

    /** [full] is where the entire original image sits in canvas coordinates. */
    fun drawCovers(canvas: Canvas, covers: List<Cover>, blurred: Bitmap, full: RectF) {
        val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        for (c in covers) {
            val r = c.rect.toScreen(full)
            when (c.type) {
                CoverType.SOLID -> {
                    val p = Paint().apply { color = c.color; style = Paint.Style.FILL }
                    canvas.drawRect(r, p)
                }
                CoverType.BLUR, CoverType.EMOJI -> {
                    canvas.save()
                    canvas.clipRect(r)
                    canvas.drawBitmap(blurred, null, full, bmpPaint)
                    canvas.restore()
                    if (c.type == CoverType.EMOJI) drawEmoji(canvas, c.emoji, r)
                }
            }
        }
    }

    private fun drawEmoji(canvas: Canvas, emoji: String, r: RectF) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = min(r.width(), r.height()) * 0.85f
        val fm = paint.fontMetrics
        val baseline = r.centerY() - (fm.ascent + fm.descent) / 2f
        canvas.drawText(emoji, r.centerX(), baseline, paint)
    }
}
