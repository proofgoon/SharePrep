package com.shareprep.ui

import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel

/** Holds the queue of picked images. The first item is the one being processed. */
class SelectionViewModel : ViewModel() {
    val uris = mutableStateListOf<Uri>()

    val current: Uri? get() = uris.firstOrNull()

    fun add(newUris: List<Uri>) {
        newUris.forEach { if (it !in uris) uris.add(it) }
    }

    fun remove(uri: Uri) {
        uris.remove(uri)
    }

    fun finishCurrent() {
        if (uris.isNotEmpty()) uris.removeAt(0)
    }
}
