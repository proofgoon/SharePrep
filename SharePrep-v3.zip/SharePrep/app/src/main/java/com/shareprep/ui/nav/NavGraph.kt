package com.shareprep.ui.nav

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.shareprep.SharePrepApp
import com.shareprep.ui.SelectionViewModel
import com.shareprep.ui.editor.EditorScreen
import com.shareprep.ui.gallery.ShareReadyScreen
import com.shareprep.ui.gallery.TrashScreen
import com.shareprep.ui.home.HomeScreen
import com.shareprep.ui.tags.TagAssignScreen
import com.shareprep.ui.tags.TagManageScreen

private fun goNext(nav: NavController, selection: SelectionViewModel) {
    if (selection.current != null) {
        nav.navigate("editor") { popUpTo("home") }
    } else {
        nav.popBackStack("home", false)
    }
}

@Composable
fun AppNav(app: SharePrepApp) {
    val nav = rememberNavController()
    val repo = app.repository
    val selection: SelectionViewModel = viewModel()

    NavHost(navController = nav, startDestination = "home") {

        composable("home") {
            HomeScreen(
                selection = selection,
                onProcess = { nav.navigate("editor") },
                onGallery = { nav.navigate("gallery") },
                onTags = { nav.navigate("tagmanage") }
            )
        }

        composable("editor") {
            EditorScreen(
                selection = selection,
                repo = repo,
                onApproved = { id ->
                    selection.finishCurrent()
                    nav.navigate("tags/$id?batch=true")
                },
                onSkip = {
                    selection.finishCurrent()
                    goNext(nav, selection)
                },
                onBack = { nav.popBackStack() }
            )
        }

        composable(
            route = "tags/{imageId}?batch={batch}",
            arguments = listOf(
                navArgument("imageId") { type = NavType.LongType },
                navArgument("batch") { type = NavType.BoolType; defaultValue = false }
            )
        ) { entry ->
            val imageId = entry.arguments?.getLong("imageId") ?: 0L
            val batch = entry.arguments?.getBoolean("batch") ?: false
            TagAssignScreen(
                repo = repo,
                imageId = imageId,
                batch = batch,
                remaining = selection.uris.size,
                onDone = { if (batch) goNext(nav, selection) else nav.popBackStack() },
                onBack = { nav.popBackStack() }
            )
        }

        composable("gallery") {
            ShareReadyScreen(
                repo = repo,
                onBack = { nav.popBackStack() },
                onEditTags = { id -> nav.navigate("tags/$id?batch=false") },
                onManageTags = { nav.navigate("tagmanage") },
                onTrash = { nav.navigate("trash") }
            )
        }

        composable("tagmanage") { TagManageScreen(repo) { nav.popBackStack() } }
        composable("trash") { TrashScreen(repo) { nav.popBackStack() } }
    }
}
