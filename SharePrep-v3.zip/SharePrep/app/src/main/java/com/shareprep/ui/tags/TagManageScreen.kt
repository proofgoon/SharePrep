@file:OptIn(ExperimentalMaterial3Api::class)

package com.shareprep.ui.tags

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.shareprep.data.Repository
import com.shareprep.data.db.TagWithCount
import com.shareprep.ui.BackButton
import com.shareprep.ui.appViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TagManageViewModel(private val repo: Repository) : ViewModel() {
    val tags = repo.tagsWithCounts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    fun add(name: String) { viewModelScope.launch { repo.createTag(name) } }
    fun delete(id: Long) { viewModelScope.launch { repo.deleteTag(id) } }
}

@Composable
fun TagManageScreen(repo: Repository, onBack: () -> Unit) {
    val vm = appViewModel { TagManageViewModel(repo) }
    val tags by vm.tags.collectAsStateWithLifecycle()
    var newName by remember { mutableStateOf("") }
    var pendingDelete by remember { mutableStateOf<TagWithCount?>(null) }

    fun add() {
        vm.add(newName)
        newName = ""
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Tags") }, navigationIcon = { BackButton(onBack) }) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("New tag") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { add() })
                )
                Button(onClick = { add() }, enabled = newName.isNotBlank()) { Text("Add") }
            }
            if (tags.isEmpty()) {
                Text("No tags yet.", style = MaterialTheme.typography.bodyMedium)
            }
            LazyColumn(Modifier.fillMaxWidth()) {
                items(tags, key = { it.id }) { t ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(t.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (t.count == 1) "1 image" else "${t.count} images",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { pendingDelete = t }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete tag")
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    pendingDelete?.let { t ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete tag \"${t.name}\"?") },
            text = { Text("It will be removed from all images. The images themselves stay.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(t.id); pendingDelete = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } }
        )
    }
}
