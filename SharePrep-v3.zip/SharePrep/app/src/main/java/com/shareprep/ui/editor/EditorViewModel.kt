package com.shareprep.ui.editor

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shareprep.data.Repository
import com.shareprep.editor.BitmapLoader
import com.shareprep.editor.BitmapProcessor
import com.shareprep.editor.Cover
import com.shareprep.editor.CoverRenderer
import com.shareprep.editor.CoverType
import com.shareprep.editor.EditMode
import com.shareprep.editor.NRect
import com.shareprep.editor.fitInto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditorViewModel(
    application: Application,
    private val repo: Repository
) : AndroidViewModel(application) {

    private var loadedUri: Uri? = null
    private var nextId = 1L

    var bitmap by mutableStateOf<Bitmap?>(null)
        private set
    var blurred by mutableStateOf<Bitmap?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var saving by mutableStateOf(false)
        private set

    var mode by mutableStateOf(EditMode.CROP)
        private set
    var crop by mutableStateOf(NRect.FULL)
        private set
    val covers = mutableStateListOf<Cover>()
    var selectedId by mutableStateOf<Long?>(null)
        private set

    val selected: Cover? get() = covers.firstOrNull { it.id == selectedId }
    val hasEdits: Boolean get() = crop != NRect.FULL || covers.isNotEmpty()

    fun load(uri: Uri) {
        if (loadedUri == uri) return
        loadedUri = uri
        viewModelScope.launch {
            try {
                val bmp = BitmapLoader.load(getApplication(), uri)
                val bl = withContext(Dispatchers.Default) { CoverRenderer.makeBlurred(bmp) }
                bitmap = bmp
                blurred = bl
            } catch (e: Exception) {
                error = "Couldn't open this image."
            }
        }
    }

    fun switchMode(m: EditMode) {
        if (m == EditMode.COVER) {
            for (i in covers.indices) {
                covers[i] = covers[i].copy(rect = fitInto(covers[i].rect, crop))
            }
        }
        mode = m
    }

    fun setCrop(r: NRect) { crop = r }
    fun resetCrop() { crop = NRect.FULL }

    fun addCover(type: CoverType) {
        val c = crop
        val w = c.width * 0.4f
        val h = c.height * 0.4f
        val cx = (c.left + c.right) / 2f
        val cy = (c.top + c.bottom) / 2f
        val cover = Cover(nextId++, type, NRect(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f))
        covers.add(cover)
        selectedId = cover.id
        mode = EditMode.COVER
    }

    fun select(id: Long?) { selectedId = id }

    fun updateCoverRect(id: Long, rect: NRect) {
        val i = covers.indexOfFirst { it.id == id }
        if (i >= 0) covers[i] = covers[i].copy(rect = rect)
    }

    fun deleteSelected() {
        val id = selectedId ?: return
        covers.removeAll { it.id == id }
        selectedId = null
    }

    fun setColor(argb: Int) = updateSelected { it.copy(color = argb) }
    fun setEmoji(e: String) = updateSelected { it.copy(emoji = e) }

    private fun updateSelected(change: (Cover) -> Cover) {
        val i = covers.indexOfFirst { it.id == selectedId }
        if (i >= 0) covers[i] = change(covers[i])
    }

    fun approve(onSaved: (Long) -> Unit) {
        val src = bitmap ?: return
        if (saving) return
        saving = true
        viewModelScope.launch {
            try {
                val edited = hasEdits
                val out = if (edited) {
                    val c = crop
                    val list = covers.toList()
                    withContext(Dispatchers.Default) { BitmapProcessor.process(src, c, list) }
                } else src
                val id = repo.approve(out, edited)
                onSaved(id)
            } catch (e: Exception) {
                error = "Couldn't save this image."
            } finally {
                saving = false
            }
        }
    }
}
