@file:OptIn(ExperimentalMaterial3Api::class)

package com.shareprep.ui.gallery

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.shareprep.data.Repository
import com.shareprep.data.db.ImageWithTags
import com.shareprep.ui.BackButton
import com.shareprep.ui.appViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

class GalleryViewModel(private val repo: Repository) : ViewModel() {
    val tags = repo.tagsWithCounts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _filter = MutableStateFlow<Set<Long>>(emptySet())
    val filter: StateFlow<Set<Long>> = _filter

    @OptIn(ExperimentalCoroutinesApi::class)
    val images = _filter
        .flatMapLatest { repo.shareReady(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun toggle(tagId: Long) {
        _filter.update { if (tagId in it) it - tagId else it + tagId }
    }

    fun clearFilter() { _filter.value = emptySet() }
    fun trash(id: Long) { viewModelScope.launch { repo.moveToTrash(id) } }
    fun shareUri(path: String): Uri = repo.shareUri(path)
}

fun shareImage(context: Context, uri: Uri) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "image/jpeg"
        putExtra(Intent.EXTRA_STREAM, uri)
        clipData = ClipData.newRawUri("", uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(send, "Share image"))
}

@Composable
fun ShareReadyScreen(
    repo: Repository,
    onBack: () -> Unit,
    onEditTags: (Long) -> Unit,
    onManageTags: () -> Unit,
    onTrash: () -> Unit
) {
    val vm = appViewModel { GalleryViewModel(repo) }
    val rows by vm.images.collectAsStateWithLifecycle()
    val tags by vm.tags.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Share Ready") },
                navigationIcon = { BackButton(onBack) },
                actions = {
                    TextButton(onClick = onTrash) { Text("Trash") }
                    TextButton(onClick = onManageTags) { Text("Tags") }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = filter.isEmpty(),
                        onClick = { vm.clearFilter() },
                        label = { Text("All") }
                    )
                }
                items(tags, key = { it.id }) { t ->
                    FilterChip(
                        selected = t.id in filter,
                        onClick = { vm.toggle(t.id) },
                        label = { Text("${t.name} (${t.count})") }
                    )
                }
            }

            if (rows.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        if (filter.isEmpty()) "Nothing here yet. Approve some images first."
                        else "No images with these tags.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(160.dp),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(rows, key = { it.image.id }) { item ->
                        ImageCard(
                            item = item,
                            onShare = { shareImage(context, vm.shareUri(item.image.filePath)) },
                            onEditTags = { onEditTags(item.image.id) },
                            onTrash = { vm.trash(item.image.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ImageCard(
    item: ImageWithTags,
    onShare: () -> Unit,
    onEditTags: () -> Unit,
    onTrash: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    Card {
        Column {
            AsyncImage(
                model = File(item.image.filePath),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(1f)
            )
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (item.tags.isEmpty()) "No tags" else item.tags.joinToString(", ") { it.name },
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onShare) {
                    Icon(Icons.Default.Share, contentDescription = "Share")
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Edit tags") },
                            onClick = { menuOpen = false; onEditTags() }
                        )
                        DropdownMenuItem(
                            text = { Text("Move to Trash") },
                            onClick = { menuOpen = false; onTrash() }
                        )
                    }
                }
            }
        }
    }
}
