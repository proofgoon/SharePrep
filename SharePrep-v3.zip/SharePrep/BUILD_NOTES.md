SharePrep - build notes
=======================
Toolchain (matches the setup that already built on GitHub Actions):
  AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21 + Compose compiler plugin, KSP 2.0.21-1.0.28,
  Compose BOM 2024.09.03, Room 2.6.1, Coil 2.7.0, compileSdk/targetSdk 35, minSdk 31.
